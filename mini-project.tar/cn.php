<?php
/* To be configured during installation */
$db_hostname = 'localhost';
$db_username = 'himanshu';
$db_password = 'test_123';
$database = 'mini_project';
$cn=mysql_connect($db_hostname, $db_username, $db_password);
mysql_select_db($database,$cn);
if($cn === NULL){
    echo "Database connection error";
 die('mysql connection error: '.mysql_error());
}
?>
